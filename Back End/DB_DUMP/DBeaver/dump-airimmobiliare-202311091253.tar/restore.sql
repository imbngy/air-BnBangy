--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE airimmobiliare;
--
-- Name: airimmobiliare; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE airimmobiliare WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Italian_Italy.1252';


ALTER DATABASE airimmobiliare OWNER TO postgres;

\connect airimmobiliare

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: aste; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.aste (
    id bigint NOT NULL,
    compratore character varying(255),
    id_annuncio bigint NOT NULL,
    prezzo_attuale integer NOT NULL,
    prezzo_iniziale integer NOT NULL
);


ALTER TABLE public.aste OWNER TO postgres;

--
-- Name: aste_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.aste_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.aste_id_seq OWNER TO postgres;

--
-- Name: aste_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.aste_id_seq OWNED BY public.aste.id;


--
-- Name: immagini; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immagini (
    id bigint NOT NULL,
    id_annuncio bigint NOT NULL,
    url character varying(255),
    immobile bigint
);


ALTER TABLE public.immagini OWNER TO postgres;

--
-- Name: immagini_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immagini_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.immagini_id_seq OWNER TO postgres;

--
-- Name: immagini_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.immagini_id_seq OWNED BY public.immagini.id;


--
-- Name: immobili; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.immobili (
    id bigint NOT NULL,
    categoria character varying(255),
    descrizione character varying(255),
    id_proprietario bigint NOT NULL,
    in_asta boolean NOT NULL,
    indirizzo character varying(255),
    metri_quadri double precision NOT NULL,
    nome character varying(255),
    prezzo_iniziale double precision NOT NULL,
    venduto boolean NOT NULL,
    asta_id bigint,
    utente_id bigint,
    prezzo_attuale double precision
);


ALTER TABLE public.immobili OWNER TO postgres;

--
-- Name: immobili_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immobili_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.immobili_id_seq OWNER TO postgres;

--
-- Name: immobili_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.immobili_id_seq OWNED BY public.immobili.id;


--
-- Name: immobili_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.immobili_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.immobili_seq OWNER TO postgres;

--
-- Name: recensioni; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.recensioni (
    id bigint NOT NULL,
    autore character varying(255),
    id_immobile bigint NOT NULL,
    id_utente bigint NOT NULL,
    testo character varying(255),
    titolo character varying(255),
    voto smallint,
    immobili_id bigint,
    utenti_id bigint,
    data timestamp(6) without time zone
);


ALTER TABLE public.recensioni OWNER TO postgres;

--
-- Name: recensioni_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.recensioni_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.recensioni_id_seq OWNER TO postgres;

--
-- Name: recensioni_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.recensioni_id_seq OWNED BY public.recensioni.id;


--
-- Name: utenti; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.utenti (
    id bigint NOT NULL,
    admin boolean NOT NULL,
    banned boolean NOT NULL,
    cognome character varying(255),
    email character varying(255),
    nome character varying(255),
    seller boolean NOT NULL,
    telefono bigint,
    password character varying(255)
);


ALTER TABLE public.utenti OWNER TO postgres;

--
-- Name: utenti_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utenti_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.utenti_id_seq OWNER TO postgres;

--
-- Name: utenti_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.utenti_id_seq OWNED BY public.utenti.id;


--
-- Name: utenti_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.utenti_seq
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.utenti_seq OWNER TO postgres;

--
-- Name: aste id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste ALTER COLUMN id SET DEFAULT nextval('public.aste_id_seq'::regclass);


--
-- Name: immagini id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immagini ALTER COLUMN id SET DEFAULT nextval('public.immagini_id_seq'::regclass);


--
-- Name: immobili id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili ALTER COLUMN id SET DEFAULT nextval('public.immobili_id_seq'::regclass);


--
-- Name: recensioni id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni ALTER COLUMN id SET DEFAULT nextval('public.recensioni_id_seq'::regclass);


--
-- Name: utenti id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti ALTER COLUMN id SET DEFAULT nextval('public.utenti_id_seq'::regclass);


--
-- Data for Name: aste; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.aste (id, compratore, id_annuncio, prezzo_attuale, prezzo_iniziale) FROM stdin;
\.
COPY public.aste (id, compratore, id_annuncio, prezzo_attuale, prezzo_iniziale) FROM '$$PATH$$/4826.dat';

--
-- Data for Name: immagini; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immagini (id, id_annuncio, url, immobile) FROM stdin;
\.
COPY public.immagini (id, id_annuncio, url, immobile) FROM '$$PATH$$/4828.dat';

--
-- Data for Name: immobili; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.immobili (id, categoria, descrizione, id_proprietario, in_asta, indirizzo, metri_quadri, nome, prezzo_iniziale, venduto, asta_id, utente_id, prezzo_attuale) FROM stdin;
\.
COPY public.immobili (id, categoria, descrizione, id_proprietario, in_asta, indirizzo, metri_quadri, nome, prezzo_iniziale, venduto, asta_id, utente_id, prezzo_attuale) FROM '$$PATH$$/4830.dat';

--
-- Data for Name: recensioni; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.recensioni (id, autore, id_immobile, id_utente, testo, titolo, voto, immobili_id, utenti_id, data) FROM stdin;
\.
COPY public.recensioni (id, autore, id_immobile, id_utente, testo, titolo, voto, immobili_id, utenti_id, data) FROM '$$PATH$$/4832.dat';

--
-- Data for Name: utenti; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.utenti (id, admin, banned, cognome, email, nome, seller, telefono, password) FROM stdin;
\.
COPY public.utenti (id, admin, banned, cognome, email, nome, seller, telefono, password) FROM '$$PATH$$/4834.dat';

--
-- Name: aste_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.aste_id_seq', 5, true);


--
-- Name: immagini_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immagini_id_seq', 33, true);


--
-- Name: immobili_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immobili_id_seq', 16, true);


--
-- Name: immobili_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.immobili_seq', 1, false);


--
-- Name: recensioni_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.recensioni_id_seq', 5, true);


--
-- Name: utenti_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utenti_id_seq', 16, true);


--
-- Name: utenti_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.utenti_seq', 1, false);


--
-- Name: aste aste_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.aste
    ADD CONSTRAINT aste_pkey PRIMARY KEY (id);


--
-- Name: immagini immagini_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immagini
    ADD CONSTRAINT immagini_pkey PRIMARY KEY (id);


--
-- Name: immobili immobili_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT immobili_pkey PRIMARY KEY (id);


--
-- Name: recensioni recensioni_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT recensioni_pkey PRIMARY KEY (id);


--
-- Name: immobili uk_615qe4ah580tqs5dlrcb35r0o; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT uk_615qe4ah580tqs5dlrcb35r0o UNIQUE (asta_id);


--
-- Name: immobili uk_od777ghoc4o0kwrdoy5sk7b5m; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT uk_od777ghoc4o0kwrdoy5sk7b5m UNIQUE (utente_id);


--
-- Name: utenti utenti_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.utenti
    ADD CONSTRAINT utenti_pkey PRIMARY KEY (id);


--
-- Name: recensioni fk1yvghpay14oq90xee8ijg0gwq; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT fk1yvghpay14oq90xee8ijg0gwq FOREIGN KEY (utenti_id) REFERENCES public.utenti(id);


--
-- Name: recensioni fk6xnlofhjtcd7qaxs8i93tmifu; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.recensioni
    ADD CONSTRAINT fk6xnlofhjtcd7qaxs8i93tmifu FOREIGN KEY (immobili_id) REFERENCES public.immobili(id);


--
-- Name: immobili fkdburjmpr7sse511iu6cwh62u7; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT fkdburjmpr7sse511iu6cwh62u7 FOREIGN KEY (utente_id) REFERENCES public.utenti(id);


--
-- Name: immagini fknknp1emml2dsgaduwqeqrn0hh; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immagini
    ADD CONSTRAINT fknknp1emml2dsgaduwqeqrn0hh FOREIGN KEY (immobile) REFERENCES public.immobili(id);


--
-- Name: immobili fkp3dhvdbpa3qiwpcud7xfef5g1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.immobili
    ADD CONSTRAINT fkp3dhvdbpa3qiwpcud7xfef5g1 FOREIGN KEY (asta_id) REFERENCES public.aste(id);


--
-- PostgreSQL database dump complete
--

